'use client'
import React, { useState } from 'react'

export default function ProduitPage() {
  const [loading, setLoading] = useState(false)
  const handleBuy = async () => {
    setLoading(true)
    const res = await fetch('/api/checkout', { method: 'POST' })
    const json = await res.json()
    setLoading(false)
    window.location.href = `/confirmation?orderId=${json.orderId}`
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Ebook : \"Démarrer avec le numérique\"</h2>
      <p>Un exemple d'ebook numérique pour tester la boutique.</p>
      <div className="bg-white p-4 rounded shadow-sm">
        <p className="text-lg font-medium">Prix : 0 XOF (paiement fictif)</p>
        <button
          onClick={handleBuy}
          disabled={loading}
          className="mt-4 inline-block px-4 py-2 rounded bg-blue-600 text-white disabled:opacity-50"
        >
          {loading ? 'Traitement...' : 'Acheter'}
        </button>
      </div>
    </div>
  )
}
