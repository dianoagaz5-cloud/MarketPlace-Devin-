import './globals.css'
import React from 'react'

export const metadata = {
  title: 'Prototype Chariow - FR',
  description: "Prototype minimal d'une boutique de produits numériques"
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="fr">
      <body className="min-h-screen bg-gray-50 text-gray-900">
        <header className="bg-white shadow">
          <div className="max-w-4xl mx-auto p-4">
            <h1 className="text-xl font-semibold">Prototype Chariow</h1>
          </div>
        </header>
        <main className="max-w-4xl mx-auto p-6">{children}</main>
        <footer className="text-center p-6 text-sm text-gray-500">Prototype — Paiement fictif</footer>
      </body>
    </html>
  )
}
