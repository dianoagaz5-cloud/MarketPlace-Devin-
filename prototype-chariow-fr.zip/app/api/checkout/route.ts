import { NextResponse } from 'next/server'

export async function POST() {
  const orderId = 'ORD-' + Math.random().toString(36).slice(2, 9).toUpperCase()
  return NextResponse.json({ ok: true, orderId })
}
