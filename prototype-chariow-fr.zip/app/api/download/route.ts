import { NextResponse } from 'next/server'
import path from 'path'
import fs from 'fs'

export async function GET(request: Request) {
  const url = new URL(request.url)
  const orderId = url.searchParams.get('orderId')
  if (!orderId) return new NextResponse('OrderId manquant', { status: 400 })

  const filePath = path.join(process.cwd(), 'public', 'ebook-sample.pdf')
  const file = await fs.promises.readFile(filePath)
  return new NextResponse(file, {
    status: 200,
    headers: { 'Content-Type': 'application/pdf' }
  })
}
