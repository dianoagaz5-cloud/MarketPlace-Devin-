'use client'
import React, { useEffect, useState } from 'react'
import { useSearchParams } from 'next/navigation'

export default function ConfirmationPage() {
  const params = useSearchParams()
  const orderId = params.get('orderId')
  const [downloadReady, setDownloadReady] = useState(false)

  useEffect(() => {
    const fetchDownload = async () => {
      const res = await fetch(`/api/download?orderId=${orderId}`)
      if (res.ok) setDownloadReady(true)
    }
    if (orderId) fetchDownload()
  }, [orderId])

  return (
    <div className="space-y-4">
      <h2 className="text-2xl font-bold">Merci pour votre commande</h2>
      <p>Commande : <strong>{orderId}</strong></p>
      {downloadReady ? (
        <a href={`/api/download?orderId=${orderId}`} className="underline">Télécharger l'ebook</a>
      ) : (
        <p>Préparation du téléchargement...</p>
      )}
    </div>
  )
}
